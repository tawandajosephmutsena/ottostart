<?php

return [
    'name' => 'DemoPlugin',
];
