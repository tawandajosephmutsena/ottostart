<?php

namespace Modules\DemoPlugin\Database\Seeders;

use Illuminate\Database\Seeder;

class DemoPluginDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
