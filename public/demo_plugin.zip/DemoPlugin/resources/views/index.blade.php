<x-demoplugin::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('demoplugin.name') !!}</p>
</x-demoplugin::layouts.master>
